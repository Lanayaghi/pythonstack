from django.apps import AppConfig


class SemiTvAppConfig(AppConfig):
    name = 'semi_tv_app'
