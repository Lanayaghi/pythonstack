from django.apps import AppConfig


class LogAppConfig(AppConfig):
    name = 'log_app'
